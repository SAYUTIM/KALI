const CHECK_INTERVAL = 1500; // 1.5秒
var check = 3;

function checkAndExecute() {
    
    const now = new Date();
    const day = now.getDay(); // 0 = 日曜日, 1 = 月曜日, ..., 4 = 木曜日
    const hours = now.getHours();
    const minutes = now.getMinutes();

    if (day === 4 && hours === 10 && minutes === 9 && check) {

        if (!location.href.startsWith("https://study.ns.kogakuin.ac.jp/lms/homeHoml/doIndex;SID=")) {
            window.location.href = 'https://study.ns.kogakuin.ac.jp/';
        }

        const logic = document.querySelector("a[onclick^=\"formSubmit('KOG0000000054344')\"]");
        if (logic && check === 3) {
            logic.click();
            check--;
        }

        const attendpush = document.querySelector("a[onclick^=\"syussekiSentakuAdd();\"]");
        if (attendpush && check === 2) {
            attendpush.click();
            check--;
        }

        const pushok = document.querySelector("a[onclick^=\"enter();\"]");
        if (pushok && check === 1) {
            pushok.click();
            check--;
            window.location.href = 'https://meet.google.com/gqp-eujm-ddc';
        }

    }

    if (day === 4 && hours === 11 && minutes === 35 && !check) {
        const outattend = document.querySelector('[aria-label="通話から退出"]');
        if (outattend) outattend.click();
        window.location.href = 'https://study.ns.kogakuin.ac.jp/';   
    }
}

setInterval(checkAndExecute, CHECK_INTERVAL);